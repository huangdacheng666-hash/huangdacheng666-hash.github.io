"""
minimax-docx engine - Document compilation and validation toolkit.
"""
