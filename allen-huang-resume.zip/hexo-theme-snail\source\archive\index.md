---
layout: "archive"
title: "Archives"
header-img: "img/header_img/archive-bg.jpg"
comments: false
date: 2017-03-20 20:49:56
description: "Have goals that are actually meaningful to all of your brain, not just a piece, and immerse yourself in whatever it is you do."
---
