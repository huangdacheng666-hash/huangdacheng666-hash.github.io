"""
Packaging - OPC-compliant document packaging.
"""

from .opc import OPCPackager

__all__ = ["OPCPackager"]
