---
title: About Me
date: 2025-02-14 10:00:00
type: about
layout: page
comments: false
---

## About Me

My name is Huang Cheng (Allen). I have 10 years of experience in technical support and FAE team management, focusing on the intelligent hardware/IoT field, and proficient in full-process technical empowerment from customer requirements to product implementation.

### Contact Information

- **WeChat/Mobile**: 13760211420
- **Email**: 396164358@qq.com
- **Birthday**: December 1992
- **Location**: Shenzhen

### Job Intention

FAE Manager, Technical Support, Solution Engineer, Technical Sales, TPM, Project Manager

---

**语言切换**: [中文版本](/work-experience/)
