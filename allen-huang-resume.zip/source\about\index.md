---
title: 关于我
date: 2025-02-14 10:00:00
type: about
layout: page
comments: false
---

## 关于我

我叫黄成（Allen Huang），拥有10年技术支持和FAE团队管理经验，专注智能硬件/IoT领域，擅长从客户需求到产品落地的全流程技术赋能。

### 联系方式

- **微信/手机**: 13760211420
- **邮箱**: 396164358@qq.com
- **生日**: 1992.12
- **所在地**: 深圳

### 求职意向

FAE经理、技术支持、解决方案工程师、技术销售、TPM、项目经理

---

**语言切换**: [English Version](/en/work-experience/)
