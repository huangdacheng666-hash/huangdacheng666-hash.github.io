---
layout: "categories"
title: "Categories"
header-img: "img/header_img/categories-bg.jpg"
comments: false
date: 2017-03-20 20:49:56
description: "Approach the New Year with resolve to find the opportunities hidden in each new day."
---
